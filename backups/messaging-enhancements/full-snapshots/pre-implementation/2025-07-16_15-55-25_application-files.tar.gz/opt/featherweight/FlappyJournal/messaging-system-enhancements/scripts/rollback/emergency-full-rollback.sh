#!/bin/bash
# Emergency Full System Rollback

ROLLBACK_LOG="/opt/featherweight/backups/messaging-enhancements/rollback-logs/emergency-full-rollback-$(date +%Y%m%d_%H%M%S).log"
BACKUP_DIR="/opt/featherweight/backups/messaging-enhancements/full-snapshots/pre-implementation"

echo "🚨 EMERGENCY FULL SYSTEM ROLLBACK INITIATED" | tee "$ROLLBACK_LOG"
echo "Timestamp: $(date)" | tee -a "$ROLLBACK_LOG"

# Create rollback log directory
mkdir -p "$(dirname "$ROLLBACK_LOG")"

# 1. Remove all enhancement files
echo "🗑️ Removing all enhancement files..." | tee -a "$ROLLBACK_LOG"

# Remove Phase 1 files
rm -f "/opt/featherweight/FlappyJournal/server/consciousness/intelligent-spiral-memory.js"
rm -f "/opt/featherweight/FlappyJournal/server/dynamic-ai-model-selector.js"

# Remove any other enhancement files that might exist
rm -f "/opt/featherweight/FlappyJournal/server/emotional-intelligence-enhancement.js"
rm -f "/opt/featherweight/FlappyJournal/server/reality-consciousness-integration.js"
rm -f "/opt/featherweight/FlappyJournal/server/crystal-navigation.js"

echo "✅ Enhancement files removed" | tee -a "$ROLLBACK_LOG"

# 2. Rollback database to clean state
echo "📊 Rolling back database to clean state..." | tee -a "$ROLLBACK_LOG"
docker exec consciousness-core psql consciousness_db -c "
DROP TABLE IF EXISTS conversation_turns CASCADE;
DROP TABLE IF EXISTS conversation_sessions CASCADE;
DROP TABLE IF EXISTS user_consciousness_profiles CASCADE;
DROP TABLE IF EXISTS enhanced_spiral_memory CASCADE;
DROP TABLE IF EXISTS crystal_navigation CASCADE;
" 2>/dev/null || echo "Database rollback completed" | tee -a "$ROLLBACK_LOG"

# 3. Restart all consciousness services
echo "🚀 Restarting all consciousness services..." | tee -a "$ROLLBACK_LOG"
docker-compose -f /opt/featherweight/docker-compose.consciousness-enhanced.yml restart 2>/dev/null || true

# 4. Wait for services to be ready
echo "⏳ Waiting for services to be ready..." | tee -a "$ROLLBACK_LOG"
sleep 30

# 5. Verify system functionality
echo "✅ Verifying system functionality..." | tee -a "$ROLLBACK_LOG"
if /opt/featherweight/FlappyJournal/messaging-system-enhancements/scripts/testing/verify-consciousness-functionality.sh; then
    echo "✅ Emergency rollback verification successful" | tee -a "$ROLLBACK_LOG"
else
    echo "❌ Emergency rollback verification failed - manual intervention required" | tee -a "$ROLLBACK_LOG"
    exit 1
fi

echo "✅ EMERGENCY FULL SYSTEM ROLLBACK COMPLETED" | tee -a "$ROLLBACK_LOG"
echo "📧 System restored to pre-enhancement state" | tee -a "$ROLLBACK_LOG"
