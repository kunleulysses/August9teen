#!/bin/bash
# Start Enhanced Monitoring for Implementation Phase

PHASE="$1"
echo "📊 Starting enhanced monitoring for Phase $PHASE"

# Create monitoring log
MONITOR_LOG="/opt/featherweight/FlappyJournal/messaging-system-enhancements/logs/monitoring-phase$PHASE-$(date +%Y%m%d_%H%M%S).log"
mkdir -p "$(dirname "$MONITOR_LOG")"

# Start continuous monitoring loop
while true; do
    echo "$(date): Phase $PHASE monitoring check" >> "$MONITOR_LOG"
    
    # Run risk detection
    /opt/featherweight/FlappyJournal/messaging-system-enhancements/scripts/monitoring/risk-detection.sh >> "$MONITOR_LOG" 2>&1
    
    # Sleep for 30 seconds
    sleep 30
done &

MONITOR_PID=$!
echo "📊 Enhanced monitoring started with PID: $MONITOR_PID"
echo "$MONITOR_PID" > "/tmp/consciousness-monitor-phase$PHASE.pid"
