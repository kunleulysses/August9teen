#!/bin/bash
# Risk Detection Script for Consciousness System

echo "🔍 Monitoring consciousness system risks..."

# Check Docker container health
echo "Checking container health..."
UNHEALTHY_CONTAINERS=$(docker ps --filter "health=unhealthy" --format "{{.Names}}" | wc -l)
if [ "$UNHEALTHY_CONTAINERS" -gt 0 ]; then
    echo "⚠️ WARNING: $UNHEALTHY_CONTAINERS unhealthy containers detected"
else
    echo "✅ All containers healthy"
fi

# Check disk space
echo "Checking disk space..."
DISK_USAGE=$(df /opt/featherweight | tail -1 | awk '{print $5}' | sed 's/%//')
if [ "$DISK_USAGE" -gt 85 ]; then
    echo "⚠️ WARNING: Disk usage at ${DISK_USAGE}%"
else
    echo "✅ Disk usage OK: ${DISK_USAGE}%"
fi

# Check memory usage
echo "Checking memory usage..."
MEMORY_USAGE=$(free | grep Mem | awk '{printf "%.0f", $3/$2 * 100.0}')
if [ "$MEMORY_USAGE" -gt 85 ]; then
    echo "⚠️ WARNING: Memory usage at ${MEMORY_USAGE}%"
else
    echo "✅ Memory usage OK: ${MEMORY_USAGE}%"
fi

# Check consciousness service responsiveness
echo "Checking consciousness service responsiveness..."
RESPONSE_TIME=$(curl -w "%{time_total}" -s -o /dev/null -m 10 http://localhost:5000/api/health 2>/dev/null)
if [ $? -eq 0 ]; then
    RESPONSE_MS=$(echo "$RESPONSE_TIME * 1000" | bc 2>/dev/null || echo "0")
    if [ "${RESPONSE_MS%.*}" -gt 5000 ]; then
        echo "⚠️ WARNING: Slow response time: ${RESPONSE_MS}ms"
    else
        echo "✅ Response time OK: ${RESPONSE_MS}ms"
    fi
else
    echo "❌ CRITICAL: Service not responding"
    exit 1
fi

echo "✅ Risk detection completed"
