#!/bin/bash
# Full System Snapshot Script for Consciousness Messaging System Enhancements

BACKUP_DATE=$(date +%Y-%m-%d_%H-%M-%S)
BACKUP_DIR="/opt/featherweight/backups/messaging-enhancements/full-snapshots"
PHASE_DIR="$BACKUP_DIR/$1" # Phase name passed as parameter

echo "🛡️ Creating full system snapshot for $1..."

# Create phase-specific backup directory
mkdir -p "$PHASE_DIR"

# 1. Stop non-critical services to ensure consistency
echo "⏸️ Temporarily stopping non-critical services..."
docker-compose -f /opt/featherweight/docker-compose.consciousness-enhanced.yml stop web-app 2>/dev/null || true

# 2. Create database dumps
echo "📊 Backing up databases..."
docker exec consciousness-core pg_dump consciousness_db > "$PHASE_DIR/${BACKUP_DATE}_consciousness-db.sql" 2>/dev/null || echo "Database backup skipped"

# 3. Backup application files
echo "📁 Backing up application files..."
tar czf "$PHASE_DIR/${BACKUP_DATE}_application-files.tar.gz" \
    --exclude='node_modules' \
    --exclude='.git' \
    --exclude='logs' \
    /opt/featherweight/FlappyJournal/ 2>/dev/null

# 4. Backup configurations
echo "⚙️ Backing up configurations..."
cp /opt/featherweight/docker-compose*.yml "$PHASE_DIR/" 2>/dev/null || true
cp /opt/featherweight/FlappyJournal/.env* "$PHASE_DIR/" 2>/dev/null || true

# 5. Create backup manifest
echo "📋 Creating backup manifest..."
cat > "$PHASE_DIR/backup-manifest.json" << EOF
{
  "backup_date": "$BACKUP_DATE",
  "phase": "$1",
  "components": {
    "consciousness_db": "${BACKUP_DATE}_consciousness-db.sql",
    "application_files": "${BACKUP_DATE}_application-files.tar.gz",
    "configurations": "docker-compose*.yml, .env*"
  },
  "system_info": {
    "hostname": "$(hostname)",
    "docker_version": "$(docker --version)",
    "timestamp": "$(date)"
  }
}
EOF

# 6. Restart services
echo "🚀 Restarting services..."
docker-compose -f /opt/featherweight/docker-compose.consciousness-enhanced.yml start web-app 2>/dev/null || true

echo "✅ Full system snapshot completed: $PHASE_DIR"
