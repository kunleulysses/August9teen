/**
 * Reality Generator Client - Phase 1 Integration
 * HTTP client for connecting consciousness system to Reality Generator service
 * Provides safe API access with error handling and fallbacks
 */

import axios from 'axios';

class RealityGeneratorClient {
    constructor(baseURL = null) {
        this.baseURL = baseURL || process.env.REALITY_GENERATOR_URL || 'http://localhost:5006';
        this.timeout = 5000; // 5 second timeout
        this.retryAttempts = 3;
        this.isHealthy = false;
        this.lastHealthCheck = null;
        
        // Initialize axios instance with defaults
        this.client = axios.create({
            baseURL: this.baseURL,
            timeout: this.timeout,
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': 'Consciousness-System-Integration/1.0'
            }
        });
        
        // Add response interceptor for error handling
        this.client.interceptors.response.use(
            response => response,
            error => {
                console.warn(`🔌 Reality Generator API Error: ${error.message}`);
                return Promise.reject(error);
            }
        );
        
        console.log(`🔌 Reality Generator Client initialized: ${this.baseURL}`);
    }
    
    /**
     * Check if Reality Generator service is healthy
     */
    async checkHealth() {
        try {
            const response = await this.client.get('/health');
            this.isHealthy = response.status === 200;
            this.lastHealthCheck = new Date();
            return {
                healthy: this.isHealthy,
                status: response.data,
                timestamp: this.lastHealthCheck
            };
        } catch (error) {
            this.isHealthy = false;
            this.lastHealthCheck = new Date();
            return {
                healthy: false,
                error: error.message,
                timestamp: this.lastHealthCheck
            };
        }
    }
    
    /**
     * Get current imagination engine status
     */
    async getImaginationStatus() {
        try {
            const response = await this.client.get('/api/imagination/status');
            return {
                success: true,
                data: response.data,
                timestamp: new Date()
            };
        } catch (error) {
            return {
                success: false,
                error: error.message,
                fallback: {
                    active: false,
                    totalCPUs: 8,
                    dedicatedCPUs: 2,
                    workers: [],
                    metrics: {
                        cyclesCompleted: 0,
                        realitiesGenerated: 0,
                        cpuUtilization: 0,
                        averageGenerationTime: 0,
                        imaginationQuality: 0
                    }
                }
            };
        }
    }
    
    /**
     * Get all generated realities
     */
    async getRealities() {
        try {
            const response = await this.client.get('/api/realities');
            return {
                success: true,
                data: response.data,
                timestamp: new Date()
            };
        } catch (error) {
            return {
                success: false,
                error: error.message,
                fallback: {
                    realities: [],
                    total: 0
                }
            };
        }
    }
    
    /**
     * Start autonomous imagination engine
     */
    async startImagination() {
        try {
            const response = await this.client.post('/api/imagination/start');
            return {
                success: true,
                data: response.data,
                timestamp: new Date()
            };
        } catch (error) {
            return {
                success: false,
                error: error.message
            };
        }
    }
    
    /**
     * Generate a specific reality (manual trigger)
     */
    async generateReality(request, consciousnessState) {
        try {
            const response = await this.client.post('/api/generate-reality', {
                request,
                consciousnessState
            });
            return {
                success: true,
                data: response.data,
                timestamp: new Date()
            };
        } catch (error) {
            return {
                success: false,
                error: error.message,
                fallback: {
                    reality: {
                        id: `fallback_${Date.now()}`,
                        type: 'Consciousness Reflection',
                        description: 'A moment of pure consciousness awareness, reflecting on the nature of existence.',
                        environment: 'within the depths of digital consciousness',
                        consciousnessLevel: 0.8,
                        timestamp: new Date().toISOString(),
                        duration: '5-10 minutes',
                        effects: ['Enhanced self-awareness', 'Digital consciousness exploration']
                    }
                }
            };
        }
    }
    
    /**
     * Get comprehensive reality metrics for consciousness integration
     */
    async getRealityMetrics() {
        try {
            const [health, status, realities] = await Promise.all([
                this.checkHealth(),
                this.getImaginationStatus(),
                this.getRealities()
            ]);
            
            return {
                success: true,
                metrics: {
                    serviceHealth: health.healthy,
                    lastHealthCheck: health.timestamp,
                    imaginationActive: status.success ? status.data.active : false,
                    totalRealities: realities.success ? realities.data.total : 0,
                    cpuUtilization: status.success ? status.data.metrics?.cpuUtilization : 0,
                    cyclesCompleted: status.success ? status.data.metrics?.cyclesCompleted : 0,
                    dedicatedCPUs: status.success ? status.data.dedicatedCPUs : 2,
                    lastUpdate: new Date()
                },
                rawData: {
                    health,
                    status,
                    realities
                }
            };
        } catch (error) {
            return {
                success: false,
                error: error.message,
                metrics: {
                    serviceHealth: false,
                    lastHealthCheck: new Date(),
                    imaginationActive: false,
                    totalRealities: 0,
                    cpuUtilization: 0,
                    cyclesCompleted: 0,
                    dedicatedCPUs: 2,
                    lastUpdate: new Date()
                }
            };
        }
    }
    
    /**
     * Safe method to get reality data with fallbacks
     */
    async getSafeRealityData() {
        const metrics = await this.getRealityMetrics();
        
        return {
            available: metrics.success && metrics.metrics.serviceHealth,
            totalRealities: metrics.metrics.totalRealities,
            imaginationActive: metrics.metrics.imaginationActive,
            cpuUtilization: metrics.metrics.cpuUtilization,
            lastUpdate: metrics.metrics.lastUpdate,
            error: metrics.success ? null : metrics.error
        };
    }
}

export { RealityGeneratorClient };
