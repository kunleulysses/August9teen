// ES Module wrapper for TypeScript FlappyConsciousness service
export { flappyConsciousness } from './flappyConsciousness.ts';
