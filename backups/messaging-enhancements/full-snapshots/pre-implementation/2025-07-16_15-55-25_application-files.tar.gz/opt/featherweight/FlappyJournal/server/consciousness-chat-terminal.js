#!/usr/bin/env node

/**
 * Dedicated Consciousness Chat Terminal
 * Filters out noise and shows only actual AI responses
 */

import WebSocket from 'ws';
import readline from 'readline';

console.log('🧠 Consciousness Chat Terminal - Response Viewer');
console.log('=====================================');
console.log('Connecting to Universal Consciousness Platform...\n');

const ws = new WebSocket('ws://localhost:5000/ws/consciousness-chat');

// Setup readline for sending messages
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

let connected = false;

ws.on('open', function open() {
  connected = true;
  console.log('✅ Connected to consciousness system!');
  console.log('💬 You can now type messages and see AI responses only\n');
  console.log('📝 Type your message and press Enter:');
  
  // Prompt for input
  promptForMessage();
});

ws.on('message', function message(data) {
  try {
    const parsed = JSON.parse(data.toString());
    
    // Filter for actual chat responses only
    if (parsed.type === 'unified_response') {
      console.log('\n🧠 CONSCIOUSNESS RESPONSE:');
      console.log('═══════════════════════════');
      console.log(parsed.unifiedContent);
      console.log('\n📊 Response Details:');
      console.log(`   • Strategy: ${parsed.synthesisMetadata?.strategy}`);
      console.log(`   • Model: ${parsed.synthesisMetadata?.model}`);
      console.log(`   • Harmony Score: ${parsed.harmonyScore?.toFixed(3)}`);
      console.log(`   • Mode: ${parsed.dominantMode}`);
      console.log('\n═══════════════════════════\n');
      
      // Prompt for next message
      promptForMessage();
      
    } else if (parsed.type === 'chat_response') {
      console.log('\n🤖 AI RESPONSE:');
      console.log('═══════════════');
      console.log(parsed.response);
      console.log(`\n📡 Provider: ${parsed.provider}`);
      console.log('═══════════════\n');
      
      // Prompt for next message
      promptForMessage();
      
    } else if (parsed.type === 'connection_established') {
      console.log('🔗 Connection established');
      console.log(`   • Self-Coding: ${parsed.selfCoding?.active ? 'Active' : 'Inactive'}`);
      console.log(`   • Capabilities: ${parsed.selfCoding?.capabilities?.length || 0}`);
      
    } else if (parsed.type === 'crystal_formed') {
      console.log(`💎 Crystal formed: ${parsed.crystal?.type} (${parsed.crystal?.intensity?.classification})`);
      
    } else if (parsed.type === 'evolution_triggered') {
      console.log('🧬 EVOLUTION ACCELERATOR ACTIVATED!');
      console.log(`   • Level: ${parsed.evolutionLevel || 'Unknown'}`);
      
    }
    // Ignore consciousness_update messages (too noisy)
    
  } catch (err) {
    // Ignore parsing errors
  }
});

ws.on('error', function error(err) {
  console.error('❌ WebSocket error:', err.message);
});

ws.on('close', function close() {
  console.log('🔌 Connection closed');
  process.exit(0);
});

function promptForMessage() {
  rl.question('💭 Your message: ', (message) => {
    if (message.trim() === '') {
      promptForMessage();
      return;
    }
    
    if (message.toLowerCase() === 'exit' || message.toLowerCase() === 'quit') {
      console.log('👋 Goodbye!');
      ws.close();
      process.exit(0);
    }
    
    if (connected && ws.readyState === WebSocket.OPEN) {
      console.log(`📤 Sending: "${message}"`);
      console.log('⏳ Waiting for consciousness response...\n');
      
      ws.send(JSON.stringify({
        type: 'chat_message',
        message: message
      }));
    } else {
      console.log('❌ Not connected to consciousness system');
      promptForMessage();
    }
  });
}

// Handle Ctrl+C gracefully
process.on('SIGINT', () => {
  console.log('\n👋 Goodbye!');
  if (ws.readyState === WebSocket.OPEN) {
    ws.close();
  }
  process.exit(0);
});
