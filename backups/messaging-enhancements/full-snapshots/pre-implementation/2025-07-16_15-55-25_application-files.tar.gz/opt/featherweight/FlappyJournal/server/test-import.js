import { synthesizeUnifiedResponse } from './consciousness-response-synthesizer-hybrid.js';

console.log('Import successful:', typeof synthesizeUnifiedResponse);
