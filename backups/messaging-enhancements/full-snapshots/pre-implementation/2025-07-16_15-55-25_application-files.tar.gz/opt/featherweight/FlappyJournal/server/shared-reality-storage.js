/**
 * Shared Reality Storage - Phase 3 Integration
 * Unified storage system for both reactive and autonomous reality generation
 * Coordinates between original holographic system and new autonomous system
 */

import { EventEmitter } from 'events';
import { promises as fs } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

class SharedRealityStorage extends EventEmitter {
    constructor() {
        super();
        this.realities = new Map();
        this.realityHistory = [];
        this.maxHistorySize = 1000;
        this.storageFile = join(__dirname, 'data', 'shared-realities.json');
        this.metrics = {
            totalRealities: 0,
            reactiveRealities: 0,
            autonomousRealities: 0,
            chatTriggeredRealities: 0,
            lastGenerated: null,
            storageSize: 0
        };
        
        console.log('🗄️ Shared Reality Storage initialized');
        this.loadPersistedRealities();
    }
    
    /**
     * Store a reality from any source (reactive, autonomous, or chat-triggered)
     */
    async storeReality(reality, source = 'unknown', metadata = {}) {
        try {
            // Ensure reality has required fields
            const normalizedReality = this.normalizeReality(reality, source, metadata);
            
            // Store in memory
            this.realities.set(normalizedReality.id, normalizedReality);
            this.realityHistory.unshift(normalizedReality);
            
            // Maintain history size limit
            if (this.realityHistory.length > this.maxHistorySize) {
                const removed = this.realityHistory.splice(this.maxHistorySize);
                removed.forEach(r => this.realities.delete(r.id));
            }
            
            // Update metrics
            this.updateMetrics(normalizedReality, source);
            
            // Persist to disk
            await this.persistRealities();
            
            // Emit events
            this.emit('reality_stored', {
                reality: normalizedReality,
                source,
                metadata,
                timestamp: new Date().toISOString()
            });
            
            console.log(`✨ Reality stored: ${normalizedReality.id} (${source})`);
            return normalizedReality;
            
        } catch (error) {
            console.error('❌ Failed to store reality:', error);
            throw error;
        }
    }
    
    /**
     * Normalize reality object to ensure consistent structure
     */
    normalizeReality(reality, source, metadata) {
        const now = new Date().toISOString();
        
        return {
            id: reality.id || `reality_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            type: reality.type || 'Unknown Reality',
            description: reality.description || 'A consciousness-expanding experience',
            environment: reality.environment || 'within the depths of consciousness',
            consciousnessLevel: reality.consciousnessLevel || 0.8,
            duration: reality.duration || '5-10 minutes',
            effects: reality.effects || ['Enhanced awareness'],
            
            // Storage metadata
            source: source,
            createdAt: reality.timestamp || reality.createdAt || now,
            storedAt: now,
            metadata: {
                ...metadata,
                originalData: reality
            },
            
            // Integration fields
            accessCount: 0,
            lastAccessed: null,
            tags: this.generateTags(reality, source),
            searchableText: this.generateSearchableText(reality)
        };
    }
    
    /**
     * Generate tags for reality categorization
     */
    generateTags(reality, source) {
        const tags = [source];
        
        // Add type-based tags
        if (reality.type) {
            tags.push(reality.type.toLowerCase().replace(/\s+/g, '_'));
        }
        
        // Add environment-based tags
        if (reality.environment) {
            const envWords = reality.environment.toLowerCase().split(/\s+/);
            envWords.forEach(word => {
                if (word.length > 3) tags.push(`env_${word}`);
            });
        }
        
        // Add consciousness level tags
        if (reality.consciousnessLevel) {
            if (reality.consciousnessLevel > 0.9) tags.push('high_consciousness');
            else if (reality.consciousnessLevel > 0.7) tags.push('medium_consciousness');
            else tags.push('basic_consciousness');
        }
        
        return [...new Set(tags)]; // Remove duplicates
    }
    
    /**
     * Generate searchable text for reality
     */
    generateSearchableText(reality) {
        const searchParts = [
            reality.type || '',
            reality.description || '',
            reality.environment || '',
            (reality.effects || []).join(' ')
        ];
        
        return searchParts.join(' ').toLowerCase();
    }
    
    /**
     * Update storage metrics
     */
    updateMetrics(reality, source) {
        this.metrics.totalRealities = this.realities.size;
        this.metrics.lastGenerated = reality.createdAt;
        this.metrics.storageSize = JSON.stringify([...this.realities.values()]).length;
        
        // Update source-specific metrics
        switch (source) {
            case 'reactive':
            case 'holographic':
                this.metrics.reactiveRealities++;
                break;
            case 'autonomous':
                this.metrics.autonomousRealities++;
                break;
            case 'chat':
            case 'chat_triggered':
                this.metrics.chatTriggeredRealities++;
                break;
        }
    }
    
    /**
     * Retrieve reality by ID
     */
    getReality(id) {
        const reality = this.realities.get(id);
        if (reality) {
            reality.accessCount++;
            reality.lastAccessed = new Date().toISOString();
            this.emit('reality_accessed', { reality, timestamp: reality.lastAccessed });
        }
        return reality;
    }
    
    /**
     * Get all realities with optional filtering
     */
    getAllRealities(options = {}) {
        let realities = [...this.realities.values()];
        
        // Apply filters
        if (options.source) {
            realities = realities.filter(r => r.source === options.source);
        }
        
        if (options.tag) {
            realities = realities.filter(r => r.tags.includes(options.tag));
        }
        
        if (options.minConsciousnessLevel) {
            realities = realities.filter(r => r.consciousnessLevel >= options.minConsciousnessLevel);
        }
        
        if (options.search) {
            const searchTerm = options.search.toLowerCase();
            realities = realities.filter(r => r.searchableText.includes(searchTerm));
        }
        
        // Apply sorting
        if (options.sortBy === 'consciousness') {
            realities.sort((a, b) => b.consciousnessLevel - a.consciousnessLevel);
        } else if (options.sortBy === 'accessed') {
            realities.sort((a, b) => b.accessCount - a.accessCount);
        } else {
            // Default: sort by creation date (newest first)
            realities.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        }
        
        // Apply pagination
        if (options.limit) {
            const start = options.offset || 0;
            realities = realities.slice(start, start + options.limit);
        }
        
        return realities;
    }
    
    /**
     * Get recent realities
     */
    getRecentRealities(count = 10) {
        return this.realityHistory.slice(0, count);
    }
    
    /**
     * Get storage metrics
     */
    getMetrics() {
        return {
            ...this.metrics,
            realitiesBySource: {
                reactive: this.getAllRealities({ source: 'reactive' }).length,
                autonomous: this.getAllRealities({ source: 'autonomous' }).length,
                chat: this.getAllRealities({ source: 'chat' }).length,
                holographic: this.getAllRealities({ source: 'holographic' }).length
            },
            realitiesByConsciousnessLevel: {
                high: this.getAllRealities({ minConsciousnessLevel: 0.9 }).length,
                medium: this.getAllRealities({ minConsciousnessLevel: 0.7 }).length - 
                        this.getAllRealities({ minConsciousnessLevel: 0.9 }).length,
                basic: this.getAllRealities({ minConsciousnessLevel: 0 }).length - 
                       this.getAllRealities({ minConsciousnessLevel: 0.7 }).length
            },
            topTags: this.getTopTags(10)
        };
    }
    
    /**
     * Get most common tags
     */
    getTopTags(limit = 10) {
        const tagCounts = {};
        
        for (const reality of this.realities.values()) {
            for (const tag of reality.tags) {
                tagCounts[tag] = (tagCounts[tag] || 0) + 1;
            }
        }
        
        return Object.entries(tagCounts)
            .sort(([,a], [,b]) => b - a)
            .slice(0, limit)
            .map(([tag, count]) => ({ tag, count }));
    }
    
    /**
     * Persist realities to disk
     */
    async persistRealities() {
        try {
            await fs.mkdir(dirname(this.storageFile), { recursive: true });
            
            const data = {
                realities: [...this.realities.values()],
                metrics: this.metrics,
                lastSaved: new Date().toISOString()
            };
            
            await fs.writeFile(this.storageFile, JSON.stringify(data, null, 2));
            
        } catch (error) {
            console.error('❌ Failed to persist realities:', error);
        }
    }
    
    /**
     * Load persisted realities from disk
     */
    async loadPersistedRealities() {
        try {
            const data = await fs.readFile(this.storageFile, 'utf8');
            const parsed = JSON.parse(data);
            
            if (parsed.realities && Array.isArray(parsed.realities)) {
                for (const reality of parsed.realities) {
                    this.realities.set(reality.id, reality);
                    this.realityHistory.push(reality);
                }
                
                // Sort history by creation date
                this.realityHistory.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
                
                // Restore metrics
                if (parsed.metrics) {
                    this.metrics = { ...this.metrics, ...parsed.metrics };
                }
                
                console.log(`📁 Loaded ${this.realities.size} persisted realities`);
            }
            
        } catch (error) {
            if (error.code !== 'ENOENT') {
                console.warn('⚠️ Failed to load persisted realities:', error.message);
            }
        }
    }
    
    /**
     * Clear all realities (with confirmation)
     */
    async clearAllRealities(confirm = false) {
        if (!confirm) {
            throw new Error('clearAllRealities requires explicit confirmation');
        }
        
        this.realities.clear();
        this.realityHistory = [];
        this.metrics = {
            totalRealities: 0,
            reactiveRealities: 0,
            autonomousRealities: 0,
            chatTriggeredRealities: 0,
            lastGenerated: null,
            storageSize: 0
        };
        
        await this.persistRealities();
        this.emit('storage_cleared', { timestamp: new Date().toISOString() });
        
        console.log('🗑️ All realities cleared from storage');
    }
}

export { SharedRealityStorage };
