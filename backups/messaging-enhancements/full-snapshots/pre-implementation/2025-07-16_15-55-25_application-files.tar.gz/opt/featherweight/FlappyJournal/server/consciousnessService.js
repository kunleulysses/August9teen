// ES Module wrapper for TypeScript consciousness service
export { consciousnessService } from './consciousnessService.ts';
