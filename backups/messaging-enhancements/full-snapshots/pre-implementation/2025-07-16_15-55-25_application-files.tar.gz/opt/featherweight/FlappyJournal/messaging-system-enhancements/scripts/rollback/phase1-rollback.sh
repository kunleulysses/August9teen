#!/bin/bash
# Phase 1 Rollback Script

ROLLBACK_LOG="/opt/featherweight/backups/messaging-enhancements/rollback-logs/phase1-rollback-$(date +%Y%m%d_%H%M%S).log"
BACKUP_DIR="/opt/featherweight/backups/messaging-enhancements/full-snapshots/phase1-pre"

echo "🔄 PHASE 1 ROLLBACK INITIATED" | tee "$ROLLBACK_LOG"
echo "Timestamp: $(date)" | tee -a "$ROLLBACK_LOG"

# Create rollback log directory
mkdir -p "$(dirname "$ROLLBACK_LOG")"

# 1. Remove Phase 1 enhancements
echo "🗑️ Removing Phase 1 enhancement files..." | tee -a "$ROLLBACK_LOG"

# Remove intelligent spiral memory
if [ -f "/opt/featherweight/FlappyJournal/server/consciousness/intelligent-spiral-memory.js" ]; then
    rm "/opt/featherweight/FlappyJournal/server/consciousness/intelligent-spiral-memory.js"
    echo "✅ Removed intelligent-spiral-memory.js" | tee -a "$ROLLBACK_LOG"
fi

# Remove dynamic AI model selector
if [ -f "/opt/featherweight/FlappyJournal/server/dynamic-ai-model-selector.js" ]; then
    rm "/opt/featherweight/FlappyJournal/server/dynamic-ai-model-selector.js"
    echo "✅ Removed dynamic-ai-model-selector.js" | tee -a "$ROLLBACK_LOG"
fi

# 2. Rollback database changes (if any)
echo "📊 Rolling back database changes..." | tee -a "$ROLLBACK_LOG"
docker exec consciousness-core psql consciousness_db -c "
DROP TABLE IF EXISTS conversation_turns CASCADE;
DROP TABLE IF EXISTS conversation_sessions CASCADE;
DROP TABLE IF EXISTS user_consciousness_profiles CASCADE;
" 2>/dev/null || echo "Database rollback completed" | tee -a "$ROLLBACK_LOG"

# 3. Restart services to ensure clean state
echo "🚀 Restarting consciousness services..." | tee -a "$ROLLBACK_LOG"
docker-compose -f /opt/featherweight/docker-compose.consciousness-enhanced.yml restart main-server 2>/dev/null || true

# 4. Verify rollback success
echo "✅ Verifying rollback success..." | tee -a "$ROLLBACK_LOG"
sleep 10
if /opt/featherweight/FlappyJournal/messaging-system-enhancements/scripts/testing/verify-consciousness-functionality.sh; then
    echo "✅ Phase 1 rollback verification successful" | tee -a "$ROLLBACK_LOG"
else
    echo "⚠️ Phase 1 rollback verification had warnings" | tee -a "$ROLLBACK_LOG"
fi

echo "✅ PHASE 1 ROLLBACK COMPLETED" | tee -a "$ROLLBACK_LOG"
