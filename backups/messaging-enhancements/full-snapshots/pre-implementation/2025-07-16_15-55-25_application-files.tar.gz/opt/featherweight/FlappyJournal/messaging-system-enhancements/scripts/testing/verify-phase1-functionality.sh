#!/bin/bash
# Phase 1 Functionality Verification

echo "🧪 Verifying Phase 1 functionality..."

# Test intelligent spiral memory
echo "Testing intelligent spiral memory..."
if [ -f "/opt/featherweight/FlappyJournal/server/consciousness/intelligent-spiral-memory.js" ]; then
    echo "✅ Intelligent spiral memory file exists"
else
    echo "❌ Intelligent spiral memory file missing"
    exit 1
fi

# Test dynamic AI model selector
echo "Testing dynamic AI model selector..."
if [ -f "/opt/featherweight/FlappyJournal/server/dynamic-ai-model-selector.js" ]; then
    echo "✅ Dynamic AI model selector file exists"
else
    echo "❌ Dynamic AI model selector file missing"
    exit 1
fi

# Test conversation memory database tables
echo "Testing conversation memory database..."
TABLES_EXIST=$(docker exec consciousness-core psql consciousness_db -c "\dt" 2>/dev/null | grep -c "conversation_\|user_consciousness_profiles" || echo "0")
if [ "$TABLES_EXIST" -gt 0 ]; then
    echo "✅ Conversation memory tables exist"
else
    echo "⚠️ Conversation memory tables not found (may be expected)"
fi

# Test basic consciousness functionality
echo "Testing basic consciousness functionality..."
if /opt/featherweight/FlappyJournal/messaging-system-enhancements/scripts/testing/verify-consciousness-functionality.sh; then
    echo "✅ Basic consciousness functionality verified"
else
    echo "❌ Basic consciousness functionality failed"
    exit 1
fi

echo "✅ Phase 1 functionality verification completed"
