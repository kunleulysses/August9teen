#!/bin/bash
# Consciousness Functionality Verification Script

echo "🔍 Verifying consciousness functionality..."

# Test consciousness processing
echo "Testing consciousness processing..."
CONSCIOUSNESS_RESPONSE=$(curl -s -m 10 -X POST http://localhost:5000/api/consciousness/process \
    -H "Content-Type: application/json" \
    -d '{"message": "test consciousness processing"}' 2>/dev/null)

if echo "$CONSCIOUSNESS_RESPONSE" | grep -q "consciousness\|response\|success" 2>/dev/null; then
    echo "✅ Consciousness processing: OK"
else
    echo "❌ Consciousness processing: FAILED"
    exit 1
fi

# Test WebSocket connectivity
echo "Testing WebSocket connectivity..."
timeout 10 bash -c 'exec 3<>/dev/tcp/localhost/5000' 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✅ WebSocket connectivity: OK"
    exec 3<&-
    exec 3>&-
else
    echo "❌ WebSocket connectivity: FAILED"
    exit 1
fi

# Test main server health
echo "Testing main server health..."
HEALTH_RESPONSE=$(curl -s -m 5 http://localhost:5000/api/health 2>/dev/null)
if [ $? -eq 0 ]; then
    echo "✅ Main server health: OK"
else
    echo "❌ Main server health: FAILED"
    exit 1
fi

# Test reality generator integration
echo "Testing reality generator integration..."
REALITY_STATUS=$(curl -s -m 5 http://localhost:5000/api/reality/status 2>/dev/null)
if [ $? -eq 0 ]; then
    echo "✅ Reality generator integration: OK"
else
    echo "⚠️ Reality generator integration: WARNING (non-critical)"
fi

echo "✅ All critical consciousness functionality verification tests passed"
