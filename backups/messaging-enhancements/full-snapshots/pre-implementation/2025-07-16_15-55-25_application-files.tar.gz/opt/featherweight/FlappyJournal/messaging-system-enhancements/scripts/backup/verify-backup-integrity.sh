#!/bin/bash
# Backup Integrity Verification Script

BACKUP_DIR="$1"
VERIFICATION_LOG="$BACKUP_DIR/verification.log"

echo "🔍 Verifying backup integrity for: $BACKUP_DIR" | tee "$VERIFICATION_LOG"

# Verify tar.gz files
for file in "$BACKUP_DIR"/*.tar.gz; do
    if [ -f "$file" ]; then
        echo "Checking $file..." | tee -a "$VERIFICATION_LOG"
        if tar -tzf "$file" > /dev/null 2>&1; then
            echo "✅ $file: OK" | tee -a "$VERIFICATION_LOG"
        else
            echo "❌ $file: CORRUPTED" | tee -a "$VERIFICATION_LOG"
            exit 1
        fi
    fi
done

# Verify SQL dumps
for file in "$BACKUP_DIR"/*.sql; do
    if [ -f "$file" ]; then
        echo "Checking $file..." | tee -a "$VERIFICATION_LOG"
        if [ -s "$file" ]; then
            echo "✅ $file: OK" | tee -a "$VERIFICATION_LOG"
        else
            echo "❌ $file: EMPTY OR INVALID" | tee -a "$VERIFICATION_LOG"
            exit 1
        fi
    fi
done

# Verify backup manifest
if [ -f "$BACKUP_DIR/backup-manifest.json" ]; then
    echo "Checking backup manifest..." | tee -a "$VERIFICATION_LOG"
    if [ -s "$BACKUP_DIR/backup-manifest.json" ]; then
        echo "✅ backup-manifest.json: OK" | tee -a "$VERIFICATION_LOG"
    else
        echo "❌ backup-manifest.json: INVALID" | tee -a "$VERIFICATION_LOG"
        exit 1
    fi
fi

echo "✅ All backup integrity checks passed" | tee -a "$VERIFICATION_LOG"
