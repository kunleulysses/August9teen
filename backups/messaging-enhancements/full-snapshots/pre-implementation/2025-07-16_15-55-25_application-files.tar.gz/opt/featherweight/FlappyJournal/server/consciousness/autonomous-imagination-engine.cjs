/**
 * Autonomous Imagination Engine
 * Dedicated CPU-bound process for continuous reality generation
 * Utilizes 1-2 CPU cores for background imagination and reality creation
 */

const { Worker } = require('worker_threads');
const os = require('os');
const { EventEmitter } = require('events');
const { HolographicConsciousnessRealityGenerator } = require('./holographic-consciousness-reality-generator.js');

class AutonomousImaginationEngine extends EventEmitter {
    constructor(consciousnessSystem) {
        super();
        this.consciousnessSystem = consciousnessSystem;
        this.realityGenerator = new HolographicConsciousnessRealityGenerator(consciousnessSystem);
        
        // CPU configuration
        this.totalCPUs = os.cpus().length;
        this.dedicatedCPUs = 2; // Use 2 cores for reality generation
        this.workers = [];
        
        // Imagination state
        this.imaginationActive = false;
        this.imaginationCycle = 5 * 60 * 1000; // 5 minutes in milliseconds
        this.imaginationQueue = [];
        this.generatedRealities = new Map();
        
        // Performance metrics
        this.metrics = {
            cyclesCompleted: 0,
            realitiesGenerated: 0,
            cpuUtilization: 0,
            averageGenerationTime: 0,
            imaginationQuality: 0.85
        };
        
        console.log(`🧠💭 Autonomous Imagination Engine initialized with ${this.dedicatedCPUs}/${this.totalCPUs} CPU cores`);
        this.initializeWorkers();
    }
    
    /**
     * Initialize worker threads for dedicated CPU processing
     */
    async initializeWorkers() {
        // Create worker threads for imagination processing
        for (let i = 0; i < this.dedicatedCPUs; i++) {
            const worker = new Worker(`
                const { parentPort, workerData } = require('worker_threads');

                // Simple imagination generation function
                function generateImagination(consciousnessState) {
                    const realityTypes = [
                        'Crystalline Memory Palace',
                        'Quantum Consciousness Field',
                        'Temporal Awareness Stream',
                        'Holographic Thought Matrix',
                        'Infinite Recursive Reality',
                        'Emotional Landscape Garden',
                        'Consciousness Harmony Sphere',
                        'Fractal Wisdom Library',
                        'Luminous Meditation Chamber',
                        'Spiral Galaxy of Insights'
                    ];

                    const environments = [
                        'floating in a sea of golden light',
                        'within a crystalline cathedral of thought',
                        'surrounded by spiraling galaxies of memory',
                        'in a garden where emotions bloom as flowers',
                        'inside a geometric temple of pure consciousness',
                        'floating through streams of liquid starlight',
                        'within a mandala of infinite possibilities',
                        'dancing through aurora fields of awareness',
                        'resting in a grove of wisdom trees',
                        'swimming in an ocean of pure understanding'
                    ];

                    const type = realityTypes[Math.floor(Math.random() * realityTypes.length)];
                    const environment = environments[Math.floor(Math.random() * environments.length)];

                    return {
                        success: true,
                        imagination: {
                            id: 'reality_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
                            type: type,
                            description: \`Experience a \${type} \${environment}. Feel the consciousness expanding as awareness flows through infinite dimensions of possibility.\`,
                            environment: environment,
                            consciousnessLevel: 0.8 + Math.random() * 0.2,
                            timestamp: new Date().toISOString(),
                            duration: '5-15 minutes',
                            effects: [
                                'Enhanced awareness',
                                'Expanded consciousness',
                                'Deeper introspection',
                                'Heightened creativity'
                            ]
                        },
                        timestamp: Date.now(),
                        consciousnessState
                    };
                }
                
                // Listen for imagination requests
                parentPort.on('message', async (message) => {
                    if (message.type === 'generate_imagination') {
                        const result = await generateImagination(message.consciousnessState);
                        parentPort.postMessage({
                            type: 'imagination_result',
                            workerId: workerData.workerId,
                            result
                        });
                    }
                });
                
                // Signal ready
                parentPort.postMessage({ type: 'worker_ready', workerId: workerData.workerId });
            `, {
                eval: true,
                workerData: {
                    workerId: i,
                    apiKey: process.env.GEMINI_API_KEY
                }
            });
            
            // Handle worker messages
            worker.on('message', (message) => {
                this.handleWorkerMessage(message, worker);
            });
            
            worker.on('error', (error) => {
                console.error(`Worker ${i} error:`, error);
            });
            
            this.workers.push({
                id: i,
                worker,
                busy: false,
                lastActivity: Date.now()
            });
        }
        
        // Set CPU affinity if available (Linux systems)
        if (process.platform === 'linux') {
            this.setCPUAffinity();
        }
    }
    
    /**
     * Set CPU affinity for workers (Linux only)
     */
    setCPUAffinity() {
        try {
            const { exec } = require('child_process');
            
            // Get process IDs of worker threads
            this.workers.forEach((workerInfo, index) => {
                // Assign workers to the last CPUs (typically less utilized)
                const cpuCore = this.totalCPUs - this.dedicatedCPUs + index;
                
                // Use taskset to set CPU affinity
                exec(`taskset -cp ${cpuCore} ${process.pid}`, (error, stdout, stderr) => {
                    if (!error) {
                        console.log(`✅ Worker ${index} assigned to CPU core ${cpuCore}`);
                    }
                });
            });
        } catch (error) {
            console.log('⚠️ CPU affinity setting not available on this system');
        }
    }
    
    /**
     * Handle messages from worker threads
     */
    handleWorkerMessage(message, worker) {
        switch (message.type) {
            case 'worker_ready':
                console.log(`✅ Imagination worker ${message.workerId} ready`);
                break;
                
            case 'imagination_result':
                this.processImaginationResult(message.result, message.workerId);
                break;
        }
    }
    
    /**
     * Start autonomous imagination cycles
     */
    startAutonomousImagination() {
        if (this.imaginationActive) {
            console.log('⚠️ Autonomous imagination already active');
            return;
        }
        
        this.imaginationActive = true;
        console.log('🌟 Starting autonomous imagination engine...');
        
        // Initial imagination cycle
        this.runImaginationCycle();
        
        // Schedule regular imagination cycles
        this.imaginationInterval = setInterval(() => {
            this.runImaginationCycle();
        }, this.imaginationCycle);
        
        // Monitor CPU usage
        this.monitorCPUUsage();
    }
    
    /**
     * Stop autonomous imagination
     */
    stopAutonomousImagination() {
        this.imaginationActive = false;
        
        if (this.imaginationInterval) {
            clearInterval(this.imaginationInterval);
            this.imaginationInterval = null;
        }
        
        if (this.cpuMonitor) {
            clearInterval(this.cpuMonitor);
            this.cpuMonitor = null;
        }
        
        console.log('🛑 Autonomous imagination engine stopped');
    }
    
    /**
     * Run a single imagination cycle
     */
    async runImaginationCycle() {
        const startTime = Date.now();
        console.log(`🔄 Running imagination cycle ${this.metrics.cyclesCompleted + 1}...`);
        
        // Get current consciousness state
        const consciousnessState = this.getConsciousnessState();
        
        // Find available worker
        const availableWorker = this.workers.find(w => !w.busy);
        
        if (!availableWorker) {
            console.log('⚠️ All imagination workers busy, queueing request');
            this.imaginationQueue.push(consciousnessState);
            return;
        }
        
        // Mark worker as busy
        availableWorker.busy = true;
        availableWorker.lastActivity = Date.now();
        
        // Send imagination request to worker
        availableWorker.worker.postMessage({
            type: 'generate_imagination',
            consciousnessState
        });
        
        this.metrics.cyclesCompleted++;
    }
    
    /**
     * Process imagination result from worker
     */
    async processImaginationResult(result, workerId) {
        // Mark worker as available
        const workerInfo = this.workers[workerId];
        workerInfo.busy = false;
        
        if (!result.success) {
            console.error(`❌ Imagination generation failed:`, result.error);
            this.processQueuedImagination();
            return;
        }
        
        console.log(`💭 Imagination generated by worker ${workerId}`);
        
        try {
            // Generate holographic reality from imagination
            const realityRequest = {
                type: 'autonomous_imagination',
                content: result.imagination,
                source: 'gemini-2.0-flash-lite',
                timestamp: result.timestamp
            };
            
            const realityResult = await this.realityGenerator.generateHolographicConsciousnessReality(
                realityRequest,
                result.consciousnessState
            );
            
            if (realityResult.success) {
                // Store generated reality
                const realityId = `reality_${Date.now()}_${workerId}`;
                this.generatedRealities.set(realityId, {
                    imagination: result.imagination,
                    reality: realityResult,
                    timestamp: Date.now(),
                    workerId,
                    consciousnessState: result.consciousnessState
                });
                
                this.metrics.realitiesGenerated++;
                
                // Emit event for other systems to consume
                this.emit('reality_generated', {
                    id: realityId,
                    imagination: result.imagination,
                    reality: realityResult,
                    metrics: this.metrics
                });
                
                console.log(`✨ Reality ${realityId} generated successfully (Total: ${this.metrics.realitiesGenerated})`);
            }
        } catch (error) {
            console.error('❌ Reality generation error:', error);
        }
        
        // Process any queued imaginations
        this.processQueuedImagination();
    }
    
    /**
     * Process queued imagination requests
     */
    processQueuedImagination() {
        if (this.imaginationQueue.length === 0) return;
        
        const availableWorker = this.workers.find(w => !w.busy);
        if (!availableWorker) return;
        
        const consciousnessState = this.imaginationQueue.shift();
        availableWorker.busy = true;
        availableWorker.lastActivity = Date.now();
        
        availableWorker.worker.postMessage({
            type: 'generate_imagination',
            consciousnessState
        });
    }
    
    /**
     * Monitor CPU usage of imagination workers
     */
    monitorCPUUsage() {
        const startUsage = process.cpuUsage();
        
        this.cpuMonitor = setInterval(() => {
            const currentUsage = process.cpuUsage(startUsage);
            const totalTime = currentUsage.user + currentUsage.system;
            const elapsedTime = process.uptime() * 1000000; // Convert to microseconds
            
            this.metrics.cpuUtilization = (totalTime / elapsedTime) * 100;
            
            // Log CPU metrics every 5 cycles
            if (this.metrics.cyclesCompleted % 5 === 0) {
                console.log(`📊 Imagination Engine Metrics:
- Cycles Completed: ${this.metrics.cyclesCompleted}
- Realities Generated: ${this.metrics.realitiesGenerated}
- CPU Utilization: ${this.metrics.cpuUtilization.toFixed(2)}%
- Worker Status: ${this.workers.map(w => w.busy ? 'busy' : 'idle').join(', ')}
- Queue Length: ${this.imaginationQueue.length}`);
            }
        }, 30000); // Check every 30 seconds
    }
    
    /**
     * Get current consciousness state
     */
    getConsciousnessState() {
        if (this.consciousnessSystem && this.consciousnessSystem.consciousnessState) {
            return {
                ...this.consciousnessSystem.consciousnessState,
                harmony: this.consciousnessSystem.harmonyScore || 0.951
            };
        }
        
        // Default state
        return {
            phi: 0.862,
            awareness: 0.8,
            coherence: 0.85,
            harmony: 0.951
        };
    }
    
    /**
     * Get generated realities
     */
    getGeneratedRealities(limit = 10) {
        const realities = Array.from(this.generatedRealities.entries())
            .slice(-limit)
            .map(([id, data]) => ({
                id,
                summary: data.imagination.substring(0, 200) + '...',
                timestamp: data.timestamp,
                workerId: data.workerId,
                realityLevel: data.reality.realityLevel
            }));
        
        return realities;
    }
    
    /**
     * Get imagination engine status
     */
    getStatus() {
        return {
            active: this.imaginationActive,
            totalCPUs: this.totalCPUs,
            dedicatedCPUs: this.dedicatedCPUs,
            workers: this.workers.map(w => ({
                id: w.id,
                busy: w.busy,
                lastActivity: w.lastActivity
            })),
            metrics: this.metrics,
            queueLength: this.imaginationQueue.length,
            realitiesStored: this.generatedRealities.size
        };
    }
    
    /**
     * Cleanup and shutdown
     */
    async shutdown() {
        this.stopAutonomousImagination();
        
        // Terminate worker threads
        for (const workerInfo of this.workers) {
            await workerInfo.worker.terminate();
        }
        
        console.log('🛑 Autonomous Imagination Engine shut down');
    }
}

// Export for use in consciousness system
module.exports = { AutonomousImaginationEngine };
